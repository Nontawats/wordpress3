<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'db-username' );

/** MySQL database password */
define( 'DB_PASSWORD', 'db-password' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );
define('FS_METHOD', 'direct'); 
/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'AS4$I.`Vvi/u:7hm.G{<Z}t T2ovdHt0(<tj5JirA|^;C0tD42L#.M*#-UzE[v.g' );
define( 'SECURE_AUTH_KEY',  'X=tPDCYQ64WJfGJDPdkL;^lId9Bl]ZH.W>O$_ewX:1&kXh77N%5):S{Keu=IkBe5' );
define( 'LOGGED_IN_KEY',    '7Mwg|Bj#Xinh;Z{M_+8S^8O6pnGlQpE+eu$q~{bUCL&urS{5XVzrmSXpla`pLrAO' );
define( 'NONCE_KEY',        'r;,n#%#6wSmc:nyQNq`<h[)rT4W|B_tb)7Swk>u3b[>K6~+h)$2[5+i(IVBHa^z@' );
define( 'AUTH_SALT',        '46}]F1}SgQa3o{j4#tI)(#V!9,EM6GDEt*yWh78(3I,^Xfjf,O2LB#0-TPI`wJ`A' );
define( 'SECURE_AUTH_SALT', '|A;ykMnS9G0rh9n+0ooUVL_7Q4.|ly.Y~D&dBzJCBk9J|.E:*}~Iu:N[|AK+{.:!' );
define( 'LOGGED_IN_SALT',   '~9^wVI(HK)/t,%>)}z~O9KDVxd,6YNSp>g8k4gYGY6q^/MCLbC32<7^Nd5Cy+!Iv' );
define( 'NONCE_SALT',       '<@-sVXCV1IoF1E2nfAGc5J6}uu>gM|,Dm7NR4Ia/bo?P#/|5,8GK$/oG=|WHf3j)' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
